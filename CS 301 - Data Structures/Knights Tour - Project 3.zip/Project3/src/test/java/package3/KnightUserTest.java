/*
 * Project: 
 * Completion time: ? hours
 * 
 * Honor code: “I pledge that I have neither given nor received help from anyone
 * other than the instructor or the TAs for all program components included here.”
 */
package package3;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bmxfr
 */
public class KnightUserTest {

    protected Knight knight;

    public KnightUserTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
    }

    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class KnightUser.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        KnightUser.main(args);
        boolean expResult = false;
        if (args == null) {
            expResult = true;
        }
        assertEquals(true, expResult);
    }

    /**
     * Test of searchTour method, of class KnightUser.
     */
    @Test
    public void testSearchTour() {
        System.out.println("searchTour");
        Knight knight = null;
        boolean expResult = false;
        boolean result = KnightUser.searchTour(knight);
        assertEquals(expResult, result);
    }
}
