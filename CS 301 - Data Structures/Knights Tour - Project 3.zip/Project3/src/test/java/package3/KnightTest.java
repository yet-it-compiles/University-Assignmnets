/*
 * Project: 
 * Completion time: ? hours
 * 
 * Honor code: “I pledge that I have neither given nor received help from anyone
 * other than the instructor or the TAs for all program components included here.”
 */
package package3;

import java.util.Iterator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bmxfr
 */
public class KnightTest {
    Knight knight;
    public KnightTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of printGrid method, of class Knight.
     */
    @Test
    public void testPrintGrid() {
        System.out.println("printGrid - Test1");
        Position pos = new Position(3,3);
        knight.printGrid();
        System.out.println("pass");
    }

    /**
     * Test of getStart method, of class Knight.
     */
    @Test
    public void testGetStart() {
        System.out.println("getStart");
        Position pos = new Position(3,3);
                
        String result = knight.getStart();
        assertEquals(knight, result);
    }

    /**
     * Test of getGrid method, of class Knight.
     */
    @Test
    public void testGetGrid() {
        System.out.println("getGrid");
        String expResult = knight.getGrid();
        String result = knight.getGrid();
        assertEquals(expResult, result);
    }

    /**
     * Test of isOK method, of class Knight.
     */
    @Test
    public void testIsOK() {
Position pos = new Position(1,1);
knight = new Knight(3,3,pos);
assertEquals (true, knight.isOK (pos));
    }

    /**
     * Test of markAsPossible method, of class Knight.
     */
    @Test
    public void testMarkAsPossible() {
        System.out.println("markAsPossible");
        Position pos = new Position(1,1);
        int count = 1;
        knight.gameBoard[pos.getRow()][pos.getColumn()] = ++count;
    }

    /**
     * Test of isGoal method, of class Knight.
     */
    @Test
    public void testIsGoal() {
        System.out.println("isGoal");
        Position pos = null;
        Knight instance = null;
        boolean expResult = false;
        boolean result = instance.isGoal(pos);
        assertEquals(expResult, result);
    }

    /**
     * Test of markAsDeadEnd method, of class Knight.
     */
    @Test
    public void testMarkAsDeadEnd() {
        System.out.println("markAsDeadEnd");
        Position pos = null;
        Knight instance = null;
        instance.markAsDeadEnd(pos);
    }

    /**
     * Test of toString method, of class Knight.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Knight instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
    }

    /**
     * Test of iterator method, of class Knight.
     */
    @Test
    public void testIterator() {
        System.out.println("iterator");
        Position pos = null;
        Knight instance = null;
        Iterator<Position> expResult = null;
        Iterator<Position> result = instance.iterator(pos);
        assertEquals(expResult, result);
    }
    
}
