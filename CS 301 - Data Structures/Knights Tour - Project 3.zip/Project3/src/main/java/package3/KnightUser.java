/*
 * Project: 
 * Completion time: ? hours
 * 
 * Honor code: “I pledge that I have neither given nor received help from anyone
 * other than the instructor or the TAs for all program components included here.”
 */
package package3;
import java.util.*;

/**
 * The knightUser class runs the Knights Tour problem and executes the tour
 *
 * @author Tyler S. Unsworth
 * @Class CS 301 - Data Structures
 * @DateCompleted Febuary 18th, 2021
 */
public class KnightUser {

    public static void main(String[] args) {
        // Declaration of Scanner Object
        Scanner userInput = new Scanner(System.in);
        
        System.out.println("How many rows would you like to have? ");
        int row = userInput.nextInt();

        System.out.println("How many column would you like to have? ");
        int column = userInput.nextInt();

        System.out.println("What postion would you like the knight to start? ");
        int startingPositionX = userInput.nextInt();
        int startingPositionY = userInput.nextInt();

        Position pos = new Position(startingPositionX, startingPositionY);
        Knight knightTour = new Knight(row, column, pos);

        System.out.println(knightTour.getStart());
        System.out.println("\nThis is the selected gameboard and starting "
                + "location");
        knightTour.printGrid();

        System.out.println("\nOn the path to goal? " + knightTour.isGoal(pos));
        System.out.println("\nThe path is ok? " + knightTour.isOK(pos));

        knightTour.markAsPossible(pos);
        knightTour.markAsDeadEnd(pos);

        System.out.println("The path is found " + searchTour(knightTour));
        
        System.out.println(); // blank line
        knightTour.printGrid();
    }

    /**
     * Searches the tour to see if a path is found
     *
     * @param knight is being searched
     * @return if the path is possible (true) or if it's not (false)
     */
    public static boolean searchTour(Knight knight) {
        // Declaration of Tour Setup
        Position startingPosition = knight.startingCell;
        knight.markAsPossible(startingPosition);
        BackTrack backTracking = new BackTrack(knight);

        // Declaration of Tour Searching Logic
        if (knight.isGoal(startingPosition)
                || backTracking.tryToReachGoal(startingPosition)) {
            return true;
        }

        knight.markAsDeadEnd(startingPosition);
        return false;
    }
}
