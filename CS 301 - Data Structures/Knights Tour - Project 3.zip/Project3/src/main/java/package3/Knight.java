/*
 * Project: 
 * Completion time: ? hours
 * 
 * Honor code: “I pledge that I have neither given nor received help from anyone
 * other than the instructor or the TAs for all program components included here.”
 */
package package3;

import java.util.*;

public class Knight implements Application {

    // Declaration of Path and Gameboard Logic
    protected int rows, columns; // rows(m) , columns (n)
    protected int count = 0;
    protected int deadEnd = 0;
    // Declaration of Positions and Gameboard
    protected Position startingCell, finishingCell;
    protected int gameBoard[][];

    /**
     * Declaration of a parameterized constructor
     *
     * @param x is the horizontal size of the game board
     * @param y is the y vertical size of the game board
     * @param startingCell is the starting location when the game begins
     */
    Knight(int x, int y, Position startingCell) {
        //startingCell = new Position();
        this.rows = x;
        this.columns = y;
        this.startingCell = new Position(startingCell.getRow(), startingCell.getColumn());
        this.gameBoard = new int[x][y];
        count++;
        gameBoard[startingCell.getRow()][startingCell.getColumn()] = count;
    }

    /**
     * Prints the grid
     */
    public void printGrid() {
        //Declaration of Grid Printing Logic
        for (int[] gameBoardCopy : gameBoard) {
            for (int c = 0; c < gameBoardCopy.length; c++) {
                System.out.print(gameBoardCopy[c] + " ");
            }
            System.out.println();
        }
    }

    /**
     * Returns the starting location of the knight
     *
     * @return initial location defined by the user
     */
    public String getStart() {
        return "\nThe starting location of the knight is: ("
                + this.startingCell.getRow() + ","
                + this.startingCell.getColumn() + ")";
    }

    /**
     * Returns the grid size defined by the user
     *
     * @return the size of the grid
     */
    public String getGrid() {
        System.out.println();
        printGrid();
        return "\nThe grid size is " + this.rows + " by " + this.columns;
    }

    /**
     * Determines if a given position is legal or a dead end
     *
     * @param pos is the given position
     * @return a boolean value if the position is legal or not
     */
    @Override
    public boolean isOK(Position pos) {

        // 1) doesn't go off the board (inside the grid) (marked as 0)
        // 2) it hasn't been there before
        return (pos.getRow() >= 0 && pos.getRow() < gameBoard.length)
                && (pos.getColumn() >= 0 && pos.getColumn() < gameBoard[0].length)
                && (gameBoard[pos.getRow()][pos.getColumn()] == 0);
    }

    /**
     * Deices if the tour is possible or not
     * @param pos a given position
     */
    @Override
    public void markAsPossible(Position pos) {
        this.gameBoard[pos.getRow()][pos.getColumn()] = ++count;
    }

    /**
     * Sees if on path to goal
     * @param pos is the given position
     * @return a boolean value if it is a goal or not
     */
    @Override
    public boolean isGoal(Position pos) {
        if (this.count == this.rows * this.columns) {
            return true;
        }
        return false;
    }

    @Override
    public void markAsDeadEnd(Position pos) {
        count--;
        this.gameBoard[pos.getRow()][pos.getColumn()] = this.deadEnd;
    }

    @Override
    public String toString() {
        String result = "\n";

        for (int[] gameBoard1 : gameBoard) {
            for (int column = 0; column < gameBoard[0].length; column++) {
                result += String.valueOf(gameBoard1[column]) + ' ';
            }
            result += "\n";
        }
        return result;
    }

    /**
     *
     * @param pos
     * @return
     */
    @Override
    public Iterator<Position> iterator(Position pos) {
        KnightIterator newIter = new KnightIterator(pos);
        return newIter;
    }

    
    protected class KnightIterator implements Iterator<Position> {

        protected static final int MAXMOVES = 8;
        protected int row, column, moves;

        KnightIterator(Position pos) {
            row = pos.getRow();
            column = pos.getColumn();
            moves = 0;
        }

        @Override
        public boolean hasNext() {
            return moves < MAXMOVES;
        }

        @Override
        public Position next() {
            Position nextPosition = new Position();
            switch (moves++) {
                case 0:
                    nextPosition = new Position(row + 2, column + 1);
                    break;
                case 1:
                    nextPosition = new Position(row + 1, column + 2);
                    break;
                case 2:
                    nextPosition = new Position(row - 1, column + 2);
                    break;
                case 3:
                    nextPosition = new Position(row - 2, column + 1);
                    break;
                case 4:
                    nextPosition = new Position(row - 2, column - 1);
                    break;
                case 5:
                    nextPosition = new Position(row - 1, column - 2);
                    break;
                case 6:
                    nextPosition = new Position(row - 2, column + 1);
                    break;
                case 7:
                    nextPosition = new Position(row + 2, column - 1);
                    break;
            }
            return nextPosition;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}